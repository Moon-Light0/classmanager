package com.just.manager.service.impl;

public class ScoreService {
}
