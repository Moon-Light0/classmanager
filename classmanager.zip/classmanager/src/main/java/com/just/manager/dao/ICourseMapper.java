package com.just.manager.dao;

public interface ICourseMapper {
}
