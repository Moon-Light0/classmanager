package com.just.manager.service.impl;

import com.just.manager.service.IEveningStudyService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class EveningStudyService implements IEveningStudyService {

}
