package com.just.manager.service;

public interface IScoreService {
}
